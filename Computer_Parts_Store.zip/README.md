# Web-Programming-Project
Semester-long project for CSCI 4300. 

- Sounds good. I looked at what you made and it looks solid. I'll try and make some product pages and a login/sign-up page over the week.  - Joseph
- I added a placeholder for the logo. We can return to the main page if we click on the logo. - My
- I'm thinking we can do a drop down menu for each tab at the top and have the links to the products in there. - My
- Sessions are finished. The only feature we have left are the cart checkout and the search bar implementation. - Jordan
